package com.meritamerica.assignment1;

import java.io.*;

import java.math.*;

public class SavingsAccount {
		//private variables
		private double balance;
		private double interestRate;
		private double amount;
		private double openingBalance;
		//saving account class constructor
	    public SavingsAccount(double openingBalance) {
	    	this.openingBalance=openingBalance;
	    	
		}
	    
	    //setters and getters method
	    public void setBalance(double balance) {
	     this.balance=balance;
	    }
	   
	    public double getBalance() {
	    	return balance;
	    }
	    
	    public void setInterestRate(double interestRate) {
	    	this.interestRate=interestRate;
	    }
	    
	    public double getInterestRate() {
	    	return interestRate;
	    }
	    
	    public void setAmount(double amount) {
	        this.amount=amount;
	       }
	      
	       public double getAmount() {
	       	return amount;
	       }
	       
	       public void setOpenigBalance(double openigBalance) {
	       	this.openingBalance=openigBalance;
	       }
	       
	       public double openingBalance() {
	       	return openingBalance;
	       }
	       //withdraw method
	    public void  withdraw(double amount) {
	    	
	  	  if (openingBalance>=amount) {
	  		  
	  		  balance = openingBalance - amount;
	  	    	
	  	 }
	  	  
	  	  else {
	  		  
	  		  System.out.println("Invalid amount");
	  	  }
	  	  
	    }
	    
	    //overriding string method
	  	  
	  	 public String toString () {
	     	
	  		 return "Savings balance after withdraw is:" +balance;
	     }
	    	
	    //future value method
	    public double futureValue(int year) {
	    	
	    	return Math.pow((balance*interestRate), year);
	   
	    }
	  
}
 
	    



	    	
	   
	    
	    	
