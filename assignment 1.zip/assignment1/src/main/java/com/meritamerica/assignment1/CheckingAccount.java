package com.meritamerica.assignment1;

import java.io.*;

import java.math.*;

public class CheckingAccount {
	//private variables
	private double balance;
	private double interestRate;
	private double amount;
	private double openingBalance;
	//checking account class constructor
    public CheckingAccount(double openingBalance) {
    	this.openingBalance=openingBalance;
    	
	}
     //setters and getters methods
    public void setOpeningBalance(double balance) {
        this.balance=balance;
       }
      
       public double getOpeningBalance() {
       	return balance;
       }
    
    public void setBalance(double balance) {
     this.balance=balance;
    }
   
    public double getBalance() {
    	return balance;
    }
    
    public void setInterestRate(double interestRate) {
    	this.interestRate=interestRate;
    }
    
    public double getInterestRate() {
    	return interestRate;
    }
    
    public void setAmount(double amount) {
        this.amount=amount;
       }
      
       public double getAmount() {
       	return amount;
       }
       
       public void setOpenigBalance(double openigBalance) {
       	this.openingBalance=openigBalance;
       }
       
       public double openingBalance() {
       	return openingBalance;
       }
       
       //deposit method
    public void  deposit(double amount) {
    	
    	if(amount>0) {
    		balance = openingBalance+amount;
    		
    	}
    	
    	else {
    		
    		System.out.println ("amount value can not be negative!");
    	}
       
   }
    
    //overriding string method
    
    public String toString() {
    	return "after deposit chacking balance is: "+balance;
    }
    //method for future value
    public double futureValue(int year) {
    	
    	return Math.pow((balance*interestRate), year);
    	}
 }