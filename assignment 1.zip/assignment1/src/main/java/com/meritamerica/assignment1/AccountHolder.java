package com.meritamerica.assignment1;

import java.io.*;

public class AccountHolder {
	
	//private variables
	private String firstName;
	private String middleName;
	private String lastName;
	private String ssn;
	private double checkingAccountOpeningBalance;
	private double savingsAccountOpeningBalance;
	
	//constructor for account holder class
    public AccountHolder(String firstName,String middleName,String lastName,String ssn,
    		double checkingAccountOpeningBalance,double savingsAccountOpeningBalance) {
    	
    	this.firstName=firstName;
    	this.middleName=middleName;
    	this.lastName=lastName;
    	this.ssn=ssn;
    	this.checkingAccountOpeningBalance=checkingAccountOpeningBalance;
    	this.savingsAccountOpeningBalance=savingsAccountOpeningBalance;
    	
    }
    //setters and getters methods
    public String getFirstName() {
    	return firstName; 
    	
    }
    
    public void setFirstName(String newFirstName) {
    	this.firstName=newFirstName;
    }
    
    public String getMiddleName() {
    	return middleName; 
    	
    }
    
    public void setMiddleName(String newMiddleName) {
    	this.middleName=newMiddleName;
    }
    
    public String getLastName() {
    	return lastName; 
    	
    }
    
    public void setLastName(String newLastName) {
    	this.lastName=newLastName;
    }
    
    public String getSsnName() {
    	return ssn; 
    	
    }
    
    public void setSsn(String newSsn) {
    	this.ssn=newSsn;
    }
    
    public double getCheckingAccountOpeningBalanceName() {
    	return checkingAccountOpeningBalance; 
    	
    }
    
    public void setCheckingAccountOpeningBalance(double newCheckingAccountOpeningBalance) {
    	this.checkingAccountOpeningBalance=newCheckingAccountOpeningBalance;
    }
    
    public double getSavingsAccountOpeningBalanceName() {
    	return savingsAccountOpeningBalance; 
    	
    }
    
    public void setSavingsAccountOpeningBalance(double newSavingsAccountOpeningBalance) {
    	this.savingsAccountOpeningBalance=newSavingsAccountOpeningBalance;
    }
    //overriding string method
    public String toString() {
    	return "First name is: " + firstName+"\n"+ "Middle name is:"
    
    			+middleName+"\n"+"Last name is:"+lastName+"\n"+"ssn is:"+ssn+"\n"
    			+"Checking account openingBalance is: "+checkingAccountOpeningBalance+"\n"+"Saving account opening balance is:"
    			+savingsAccountOpeningBalance;
    }
    
 
    
}