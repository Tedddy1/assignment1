package com.meritamerica.assignment1;

import java.io.*;

import java.math.*;

public class MeritAmericaBankApp {
	//main method
	public static void main(String[] args) {
		//initiating first account holder
		AccountHolder c1=new AccountHolder("Adisu","Abera","Lakew","645624673 ",100,1000);
        System.out.println(c1.toString());
        
        CheckingAccount objdep = new CheckingAccount(100);
        objdep.deposit(500);
        System.out.println(objdep.toString());
        
        SavingsAccount objwit = new SavingsAccount(1000);
        objwit.withdraw(800);
        System.out.println(objwit.toString());
        //initiating second account holder
        AccountHolder c2=new AccountHolder("Aby","Mola","Tom","725644675 ",200,500);
        System.out.println(c2.toString());
        
        CheckingAccount objdep1 = new CheckingAccount(200);
        objdep1.deposit(-500);
        System.out.println(objdep1.toString());
        
        SavingsAccount objwit1 = new SavingsAccount(500);
        objwit1.withdraw(600);
        System.out.println(objwit1.toString());
        
  }
	
}